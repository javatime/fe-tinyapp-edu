

// 将数据文件引入到当前文件中

// var myapp=getApp();
// console.log(myapp.name);
// myapp.say();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    i: [],
    list: [],
    famous:[]
  },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    module.exports = this.data.famous;
    this.getmarkszb();
    // 当前的id号
    var id = options.id;
    console.log(id);
    this.setData({
      i: id
    })
  },
  getmarkszb: function () {
    let that = this;
    wx.request({
      url: 'http://dev.im-cc.com:38880/cms/viewData/subcolumn_posts/8',
      method: 'POST',
      success: function (res) {
        console.log(res.data.data.list[1].posts)
        that.setData({
          famous: res.data.data.list[1].posts,
        });
        that.show()
      }
    });
  },
  show: function () {
    let that = this;
    var i = this.data.i - 11;
    var detail = this.data.famous[i];
    that.setData({
      list: detail
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})