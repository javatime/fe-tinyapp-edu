 // 1 注册小程序
App({
    onLaunch: function (options) {
      // Do something initial when launch.
    }
});